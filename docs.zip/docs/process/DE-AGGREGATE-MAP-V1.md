# DE — Aggregate Map V1

**Statut** : Active — in progress
**Date** : 2026-07-13

---

## Aggregate Root

### Clinical Activity

**Responsibilities**

* governs clinical work
* owns Draft
* produces Clinical Contributions

**Invariants**

* one responsible Practitioner
* zero or more Contributions
* Draft never exists outside Activity

---

## Provisional Aggregate

### Clinical Handover

**Responsibilities**

* transfers clinical responsibility between Practitioners

**Invariants**

* each Handover instance is initiated by exactly one request act
* accepted at most once
* responsibility transferred only after acceptance

**Note** — A second Handover may be initiated for the same patient if a previous request was refused or abandoned. "Requested once" is an invariant of each Handover instance, not a restriction on Clinical Activity.

**Status** — Candidate. Not yet accepted. Conditional on G1 resolution and ES-005 completion (Refused / Unanswered states not yet modelled).

---

## Domain Record

### Clinical Contribution

**Responsibilities**

* carries an immutable clinical record produced by a Clinical Activity
* independently referenceable after its producing Activity is closed

**Characteristics**

* independent identity — persisted independently, referenced by ID across contexts
* no active lifecycle after validation — receives no Commands, has no mutable state
* produced by exactly one Clinical Activity
* never deleted

**Classification** — Not an Aggregate Root in the Evans sense (no child objects, no mutable state to protect). Not an Entity inside Clinical Activity (externally referenceable). Treated as an independently persisted domain record.

**Open Hotspot (H-ES-002)** — Imported historical documents may enter without a Clinical Activity. If confirmed, requires a distinct concept rather than extending Clinical Contribution.

---

## Rejected Aggregates

### Clinical Referral

**Reason** — No independent invariants identified. No lifecycle distinct from Clinical Activity.

**Modelling note** — A Referral involves two independent Clinical Activities: one by the referring Practitioner, one by the receiving Practitioner. The link between them (if any) is carried by an attribute or event, not by a coordinating Aggregate.

**Open Hotspot (ES-006)** — How are the two Clinical Activities linked in the Referral scenario? Decision deferred to ES-006.

---

## Hotspots

| ID | Question | Blocks |
|---|---|---|
| H-ES-001 | Draft granularity | Clinical Activity implementation |
| H-ES-002 | Imported documents — Clinical Contribution or distinct concept? | Clinical Contribution model |
| H-ES-003 | Clinical Observation vs Clinical Draft — same object or distinct? | Clinical Activity internals |
| H-ES-004 | Minimum invariant for Clinical Activity existence | Clinical Activity |
| H-A-006 | Can one Contribution be input to multiple future Activities? | Clinical Contribution model |
| H-CC-001 | Clinical Handover — Refused / Unanswered states | Clinical Handover Aggregate |
| ES-006 | How are referring and receiving Clinical Activities linked? | Referral model |
