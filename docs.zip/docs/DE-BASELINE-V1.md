# Statement of Completion — Domain Engineering Baseline V1

**Statut** : Accepted with documented Hotspots
**Date** : 2026-07-13

---

The first iteration of Domain Engineering is considered complete.

The behavioural baseline has successfully passed:

* Event Storming
* Internal review
* Red Team review

No behavioural contradiction requiring a redesign of the Core Domain has been identified.

---

## Decisions Frozen

### ES-001 — Domain Events

Frozen.

Validated timeline:

```
Clinical Activity Started
    ↓
Clinical Observation Recorded
    ↓
Clinical Draft Updated
    ↓
Clinical Contribution Validated
    ↓
Clinical Contribution Published
    ↓
Clinical Activity Closed
```

---

### ES-002 — Commands

Frozen.

Commands remain explicit Practitioner intentions.

Clinical reasoning remains outside the Domain.

---

### ES-003 — Policies

Frozen after corrections.

Changes:

* P-001 removed — semantic definition of Validated, not a Policy.
* Automatic closure removed as a Domain Policy.
* Activity closure remains a Practitioner decision (Human Judgment First).

---

### ES-004 — Aggregate Discovery

Current conclusion:

Clinical Activity is accepted as the first Candidate Aggregate Root.

Clinical Contribution remains intentionally unresolved until additional scenarios validate its lifecycle.

---

## Accepted Hotspots

The following questions remain intentionally open.

### H-ES-001

Draft granularity.

### H-ES-002

Publication and visibility rules (G1).

### H-ES-003

Observation vs Clinical Draft.

### H-ES-004

Minimum invariant required for a Clinical Activity to exist.

### H-A-006

Can one Clinical Contribution become the input of multiple future Clinical Activities?

---

## Governance Decision

ES-001 through ES-004 are now Frozen.

They may only be reopened if:

* a future Event Storming reveals a behavioural contradiction;
* repeated field observations invalidate an accepted invariant;
* an internal inconsistency is demonstrated.

New ideas or architectural preferences are not sufficient reasons to reopen the baseline.

---

## Next Phase

Domain Engineering continues with new reference scenarios.

Planned sequence:

* ES-005 — Clinical Handover
* ES-006 — Referral
* ES-007 — Hospital Discharge
* ES-008 — Interrupted Clinical Activity

These scenarios are expected to validate or falsify the current baseline rather than replace it.
