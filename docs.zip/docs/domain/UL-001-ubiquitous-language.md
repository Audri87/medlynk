# UL-001 — Ubiquitous Language Charter

**Statut** : Accepted
**Date** : 2026-07-13
**Version** : 2.0

---

## Contexte

MedLink est une plateforme clinique.

Le Domain Model décrit des mécanismes cliniques communs à plusieurs professions de santé.

Le langage utilisé dans l'architecture ne doit jamais être influencé par la profession ayant servi de point d'entrée au MVP.

---

## Principe fondamental

> **Le Domain décrit la pratique clinique, jamais une profession particulière.**

Les professions sont des spécialisations.

Le Domain reste générique.

---

## Règle UL-001

Lorsqu'un concept est partagé par plusieurs professions, le Domain utilise toujours le terme générique.

---

## Vocabulaire officiel

| ❌ À éviter | ✅ Terme du Domain | Justification |
| --- | --- | --- |
| Médecin | Practitioner | Valide pour médecin, infirmière, sage-femme, psychologue, kiné… |
| Consultation | Clinical Activity | Valide pour consultation, séance, visite, acte |
| Compte-rendu médical | Clinical Contribution | Valide pour note, ordonnance, compte-rendu, courrier |
| Brouillon / Notes en cours | Clinical Draft | État mutable privé pendant la production |
| Dossier médical | Care Record | Mémoire clinique longitudinale, indépendante de la profession |
| Logiciel médecin | Clinical Platform | La plateforme sert toutes les professions cliniques |
| Interface médecin | Professional Workspace | Workspace calculé pour un praticien dans un contexte donné |
| Patient / Client / Usager | Patient | Terme retenu : "patient" est le terme commun dans le contexte clinique français. |
| Passage de relais / Garde / Remplacement | Clinical Handover | Transfert de responsabilité clinique vers un autre Practitioner |
| Courrier de référé / Ordonnance de référence | Clinical Referral | Mandat d'acte spécifique sans transfert de responsabilité |
| Responsabilité clinique / Responsabilité médicale | Clinical Responsibility | Responsabilité professionnelle du Practitioner pour un Patient |
| Suivi / Coordination / Passage de relais | Clinical Continuity | Capacité à préserver la cohérence des soins dans le temps |
| Savoir clinique / Informations cliniques disponibles | Clinical Knowledge | Contributions validées disponibles pour les activités futures |
| Document externe / Résultat importé | Clinical Artifact | Objet clinique dont l'origine est extérieure à l'activité courante |

---

## Relation avec le Platform Kernel

Le Platform Kernel utilise "Actor" comme concept générique (tout entité capable d'interagir dans un Context).

Dans le Clinical Platform, "Practitioner" est la spécialisation d'Actor pour les professionnels de santé.

"Patient" est également un Actor dans le Platform Kernel — il devient sujet de soins dans le Clinical Platform.

---

## Les professions

Les professions appartiennent au niveau métier.

Exemples :

* médecin
* infirmière
* sage-femme
* psychologue
* kinésithérapeute
* orthophoniste
* ergothérapeute

Toutes réalisent des Clinical Activities.

Toutes produisent des Clinical Contributions.

Aucune ne définit le Domain.

---

## Les exemples

Les documents peuvent utiliser une profession particulière pour illustrer un scénario.

Exemple :

> Une sage-femme réalise une Clinical Activity de suivi de grossesse.

ou

> Une infirmière libérale réalise une Clinical Activity à domicile.

Ces exemples servent uniquement à illustrer un mécanisme.

Ils ne définissent jamais le modèle.

---

## Test du langage ubiquitaire

Avant d'introduire un nouveau terme dans le Domain, appliquer le test suivant :

**Le concept reste-t-il valide pour plusieurs professions ?**

Si la réponse est :

**Oui** → le concept peut appartenir au Domain.

**Non** → il s'agit probablement d'une spécialisation métier ou d'un scénario particulier.

---

## Conséquences

Cette règle protège MedLink contre un biais de conception centré sur une profession.

Elle garantit que :

* le Domain reste stable ;
* les futurs Workspaces pourront être spécialisés sans modifier le cœur du modèle ;
* de nouvelles professions pourront être intégrées sans remettre en cause l'architecture.

---

## Principe de conception

> **Les professions adaptent le Domain. Le Domain ne s'adapte jamais aux professions.**

---

---

## Registre des concepts officiels

Les définitions ci-dessous constituent la référence sémantique du Domain MedLink.

Aucun concept ne peut apparaître dans un ADR, un Event Storming, une Policy ou un Aggregate sans être défini dans cette section.

---

### Clinical Activity

**Statut** : ✅ Frozen

Un épisode borné de travail clinique professionnel réalisé par un Practitioner pour un but clinique défini.

Une Clinical Activity gouverne la production de Clinical Contributions et définit la responsabilité du Practitioner pendant cet épisode.

---

### Clinical Draft

**Statut** : ✅ Frozen

Une représentation de travail mutable créée et détenue par une Clinical Activity pendant qu'un Practitioner produit une contribution clinique.

Un Clinical Draft n'existe que pendant l'exécution d'une Clinical Activity. Il est privé au Practitioner responsable et n'a aucune valeur clinique ou médico-légale jusqu'à sa validation explicite.

* Mutable.
* Jamais partie du Care Record.
* Peut être abandonné.
* La validation transforme son contenu en Clinical Contribution.

---

### Clinical Contribution

**Statut** : ✅ Behaviour Frozen

Un enregistrement clinique immuable explicitement validé par un Practitioner en tant que résultat d'une Clinical Activity.

Une Clinical Contribution représente une connaissance clinique acceptée par son auteur et peut être référencée par de futures Clinical Activities.

* Immuable.
* Produite exactement une fois.
* Produite par exactement une Clinical Activity.
* Peut être référencée indéfiniment.

---

### Clinical Handover

**Statut** : 🟢 Provisional

Le transfert de responsabilité clinique pour un Patient d'un Practitioner à un autre.

Un Clinical Handover change qui est responsable de la continuation des soins.

---

### Clinical Referral

**Statut** : ✅ Frozen

Une demande d'un Practitioner à un autre de réaliser un acte clinique spécifique ou de fournir un avis professionnel sans transférer la responsabilité clinique.

Le Practitioner demandeur reste responsable du Patient.

---

### Clinical Responsibility

**Statut** : ✅ Frozen

La responsabilité professionnelle d'un Practitioner pour la gestion clinique d'un Patient pendant une Clinical Activity.

La Clinical Responsibility ne peut être transférée que via un Clinical Handover.

---

### Clinical Continuity

**Statut** : 🟡 Validation terrain en cours (H-CC-001)

La capacité des Clinical Activities successives à préserver et prolonger la cohérence des soins d'un Patient dans le temps.

La Clinical Continuity est assurée par l'usage approprié des Clinical Contributions et, lorsque la responsabilité change, des Clinical Handovers.

---

### Care Record

**Statut** : 🟡 Frozen with Hotspots

L'enregistrement clinique longitudinal qui préserve la connaissance clinique pertinente pour les soins d'un Patient.

Le Care Record est composé de Clinical Contributions et peut inclure des Clinical Artifacts selon des règles de provenance définies.

---

### Clinical Knowledge

**Statut** : ✅ Frozen

La connaissance clinique validée disponible pour soutenir les Clinical Activities présentes et futures.

La Clinical Knowledge croît par l'ajout de Clinical Contributions et reste indépendante du raisonnement qui les a produites.

---

### Clinical Artifact

**Statut** : ⚠️ Open Hotspot — pas encore partie du langage ubiquitaire officiel

Un objet d'information clinique dont l'origine est extérieure à la Clinical Activity courante.

Un Clinical Artifact peut provenir d'un autre Practitioner, d'un autre système d'information, d'une migration historique, ou d'un document fourni par le patient. Sa provenance diffère de celle d'une Clinical Contribution.

---

## Règle de gouvernance éditoriale

**Aucun terme ne peut apparaître dans un ADR, un Event Storming, une Policy ou un Aggregate sans être défini dans UL-001.**

Cette règle est effective à compter du 2026-07-13.

Les documents antérieurs à cette date sont exemptés — leur terminologie sera alignée lors de leur prochaine révision.

---

## Références

* ADR-0001 — Platform Kernel (Actor)
* ADR-0007 — Clinical Contribution Relationships
* ADR-0010 — Care Record Domain Definition
* CAL-001 — Clinical Activity Lifecycle
* CCF-001 — Clinical Cognition Framework
* CPP-001 — Cross-Practitioner Principle
* DE-BASELINE-V1 — Domain Engineering Baseline
* DE-AGGREGATE-MAP-V1 — Aggregate Map
