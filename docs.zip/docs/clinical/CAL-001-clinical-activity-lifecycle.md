# CAL-001 — Clinical Activity Lifecycle

**Statut** : Accepted
**Date** : 2026-07-09

---

## Contexte

Les observations terrain menées auprès de médecins, psychologues, sages-femmes, infirmières et autres praticiens montrent que leur travail ne consiste pas à manipuler un dossier médical mais à conduire une activité clinique.

Cette activité suit un cycle relativement stable, indépendamment de la profession.

Les tâches diffèrent.

Le mécanisme reste le même.

Le Clinical Activity Lifecycle formalise ce mécanisme afin de servir de référence commune au Domain Model, aux Workspaces et à l'implémentation.

---

## Principe

> **Une Clinical Activity est un processus cognitif et clinique permettant à un praticien de comprendre une situation, d'agir sous sa responsabilité et de produire une Clinical Contribution.**

Le logiciel accompagne ce cycle.

Il ne le remplace jamais.

---

## Les phases du cycle

### Phase 1 — Orientation

Le praticien s'oriente dans sa journée.

Exemples :

* consulter son planning ;
* identifier ses patients ;
* prendre connaissance des nouvelles informations ;
* préparer son environnement de travail.

Objectif :

> Identifier la prochaine activité clinique.

---

### Phase 2 — Context Reconstruction

Le praticien reconstruit rapidement la situation clinique.

Il cherche notamment :

* où en était la prise en charge ;
* ce qui a changé ;
* les éléments importants ;
* les points d'attention.

Cette reconstruction peut être très courte ou très approfondie selon le contexte.

Objectif :

> Construire une représentation mentale suffisante de la situation.

---

### Phase 3 — Clinical Interaction

Le praticien interagit avec le patient.

Selon la profession :

* entretien ;
* interrogatoire ;
* examen clinique ;
* séance thérapeutique ;
* visite à domicile ;
* réalisation d'un acte.

Objectif :

> Collecter les informations nécessaires et agir.

---

### Phase 4 — Clinical Reasoning

Le praticien construit ou ajuste son raisonnement.

Il :

* interprète ;
* compare ;
* formule des hypothèses ;
* vérifie ses hypothèses ;
* décide.

Cette phase appartient exclusivement au praticien.

Le logiciel ne prend jamais de décision clinique.

---

### Phase 5 — Formalization

Le praticien formalise le résultat de son travail.

Exemples :

* note clinique ;
* ordonnance ;
* compte rendu ;
* courrier ;
* cotation ;
* recommandations.

Objectif :

> Produire une trace fidèle de l'activité réalisée.

> **Note ouverte :** la transition entre Formalization et Contribution n'est pas automatique. Un acte explicite du praticien (validation, signature) marque le passage d'un document en cours à une Clinical Contribution officielle. L'état intermédiaire (brouillon, draft) doit être précisé lors de l'Event Storming.

---

### Phase 6 — Contribution

Le praticien valide explicitement la formalisation.

La formalisation devient une Clinical Contribution.

Cette contribution enrichit le Clinical Knowledge.

Elle devient disponible selon les règles de partage et d'autorisation.

---

### Phase 7 — Closure

L'activité est terminée.

Le Workspace est fermé.

Les ressources sont libérées.

La prochaine activité peut commencer.

---

## Représentation

```text
Orientation
      │
      ▼
Context Reconstruction
      │
      ▼
Clinical Interaction
      │
      ▼
Clinical Reasoning
      │
      ▼
Formalization
      │
      ▼  ← acte explicite du praticien
Clinical Contribution
      │
      ▼
Closure
```

---

## Invariants

### CAL-I-001

Toute Clinical Activity possède un responsable identifié.

### CAL-I-002

Le jugement clinique appartient toujours au praticien.

### CAL-I-003

Une Clinical Contribution ne peut exister qu'à l'issue d'une Clinical Activity et d'un acte de validation explicite du praticien.

### CAL-I-004

Le logiciel peut assister chaque phase.

Il ne peut remplacer aucune décision clinique.

### CAL-I-005

Chaque phase peut être interrompue puis reprise.

Le Workspace doit permettre cette reprise.

### CAL-I-006

Toutes les professions ne réalisent pas exactement les mêmes actions.

Elles traversent néanmoins les mêmes grandes phases du cycle.

---

## Relation avec le Workspace

Le Workspace accompagne le Lifecycle.

Il fournit, pour chaque phase :

* les informations pertinentes ;
* les actions disponibles ;
* les signaux d'attention.

Il ne modifie jamais le Lifecycle.

---

## Relation avec le Domain

Le Lifecycle ne crée aucun concept métier supplémentaire.

Il décrit la dynamique d'utilisation des concepts existants :

* Clinical Activity ;
* Clinical Contribution ;
* Clinical Knowledge ;
* Care Record.

---

## Relation avec le Clinical Cognition Framework

Le Clinical Cognition Framework explique les mécanismes cognitifs.

Le Clinical Activity Lifecycle décrit comment ces mécanismes s'inscrivent dans une activité clinique complète.

Le CCF explique **comment pense** le praticien.

Le CAL décrit **comment se déroule** son travail.

Les deux sont complémentaires.

| Phase CAL | Étape CCF |
|---|---|
| Orientation | Préparer |
| Context Reconstruction | Reconstruire rapidement le contexte |
| Clinical Interaction | Comprendre la situation actuelle |
| Clinical Reasoning | Prendre une décision |
| Formalization | Produire une nouvelle connaissance clinique |
| Contribution | Maintenir la continuité |
| Closure | Clôturer la charge mentale |

---

## Conséquences architecturales

Le Clinical Activity Lifecycle devient la référence pour :

* les Workspaces ;
* les Application Services ;
* l'Event Storming ;
* les scénarios du MVP.

Toute nouvelle fonctionnalité doit pouvoir être rattachée à une phase du Lifecycle.

Dans le cas contraire, sa pertinence devra être remise en question.

---

## Références

* CCF-001 — Clinical Cognition Framework
* ADR-0007 — Clinical Contribution Relationships
* ADR-0008 — Clinical Work and Clinical Knowledge
* WSP-001 — Workspace
